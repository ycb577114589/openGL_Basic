#pragma once
#include <stdio.h>

unsigned char* LoadFileContent(const char*filePath);