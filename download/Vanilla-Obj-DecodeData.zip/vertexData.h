#pragma once

class VertexData
{
public:
	float position[3];
	float normal[3];
	float texcoord[2];
};