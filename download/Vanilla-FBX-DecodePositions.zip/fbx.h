#pragma once
#include <windows.h>
#include <gl/GL.h>
#include "fbxsdk.h"

class FBXModel
{
protected:
	void ImportNode(FbxNode*node);
	void ImportMaterial(FbxNode*node);
	void ImportMesh(FbxMesh*mesh);
public:
	void Init(const char *filePath);
	void Draw();
};