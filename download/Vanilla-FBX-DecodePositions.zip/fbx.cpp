#include "fbx.h"
#include "vector3f.h"
#include <vector>
#pragma comment(lib,"libfbxsdk-md.lib")

void ImportPositions(FbxGeometryBase*geometry,std::vector<Vector3f>&positions)
{
	int controlPointCount = geometry->GetControlPointsCount();
	positions.resize(controlPointCount);
	printf("my control point count %d\n",controlPointCount);
	FbxVector4*controlPoints = geometry->GetControlPoints();
	for (int i=0;i<controlPointCount;++i)
	{
		positions[i].x = static_cast<float>(controlPoints[i].mData[0]);
		positions[i].y = static_cast<float>(controlPoints[i].mData[1]);
		positions[i].z = static_cast<float>(controlPoints[i].mData[2]);
		printf("%f,%f,%f\n",positions[i].x,positions[i].y,positions[i].z);
	}
}

void FBXModel::ImportMesh(FbxMesh*mesh)
{
	std::vector<Vector3f> positions;
	ImportPositions(mesh, positions);
	//indices

	//normal

	//texcoord
}

void FBXModel::ImportMaterial(FbxNode*node)
{

}

void FBXModel::ImportNode(FbxNode*node)
{
	//decode per node
	printf("decode %s\n",node->GetName());
	if (node->GetMesh())
	{
		printf("decode mesh of %s\n", node->GetName());
		ImportMaterial(node);
		ImportMesh(node->GetMesh());
	}
	//decode child
	int nChildNode = node->GetChildCount();
	for (int i=0;i<nChildNode;++i)
	{
		ImportNode(node->GetChild(i));
	}
}

void FBXModel::Init(const char *filePath)
{
	FbxManager*fbxManager = FbxManager::Create();
	FbxIOSettings*fbxIOSetting = FbxIOSettings::Create(fbxManager,IOSROOT);
	FbxImporter*fbxImporter = FbxImporter::Create(fbxManager, "");
	fbxManager->SetIOSettings(fbxIOSetting);
	if (fbxImporter->Initialize(filePath,-1,fbxManager->GetIOSettings()))
	{
		FbxScene*scene = FbxScene::Create(fbxManager, "");
		fbxImporter->Import(scene);

		FbxNode*rootNode = scene->GetRootNode();
		ImportNode(rootNode);
		scene->Destroy();
	}
	fbxImporter->Destroy();
	fbxIOSetting->Destroy();
	fbxManager->Destroy();
}

void FBXModel::Draw()
{

}