#pragma once
#include <windows.h>
#include <gl/GL.h>

class Ground
{
public:
	GLuint mGround;
	void Init();
	void Draw();
};