#include "fbx.h"
#include "fbxsdk.h"

#pragma comment(lib,"libfbxsdk-md.lib")

void FBXModel::Init(const char *filePath)
{
	FbxManager*fbxManager = FbxManager::Create();
	FbxIOSettings*fbxIOSetting = FbxIOSettings::Create(fbxManager,IOSROOT);
	FbxImporter*fbxImporter = FbxImporter::Create(fbxManager, "");
	fbxManager->SetIOSettings(fbxIOSetting);

	fbxImporter->Destroy();
	fbxIOSetting->Destroy();
	fbxManager->Destroy();
}

void FBXModel::Draw()
{

}