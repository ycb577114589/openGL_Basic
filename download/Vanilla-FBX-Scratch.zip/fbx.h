#pragma once
#include <windows.h>
#include <gl/GL.h>

class FBXModel
{
public:
	void Init(const char *filePath);
	void Draw();
};