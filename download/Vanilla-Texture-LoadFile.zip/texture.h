#pragma once

class Texture
{
public:
	void Init(const char*imagePath);
};