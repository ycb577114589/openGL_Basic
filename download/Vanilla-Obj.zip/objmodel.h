#pragma once

class ObjModel
{
public:
	void Init(const char*objModel);
	void Draw();
};