#include "fbx.h"

#pragma comment(lib,"libfbxsdk-md.lib")

void FBXModel::ImportMesh(FbxMesh*mesh)
{

}

void FBXModel::ImportMaterial(FbxNode*node)
{

}

void FBXModel::ImportNode(FbxNode*node)
{
	//decode per node
	printf("decode %s\n",node->GetName());
	if (node->GetMesh())
	{
		printf("decode mesh of %s\n", node->GetName());
		ImportMaterial(node);
		ImportMesh(node->GetMesh());
	}
	//decode child
	int nChildNode = node->GetChildCount();
	for (int i=0;i<nChildNode;++i)
	{
		ImportNode(node->GetChild(i));
	}
}

void FBXModel::Init(const char *filePath)
{
	FbxManager*fbxManager = FbxManager::Create();
	FbxIOSettings*fbxIOSetting = FbxIOSettings::Create(fbxManager,IOSROOT);
	FbxImporter*fbxImporter = FbxImporter::Create(fbxManager, "");
	fbxManager->SetIOSettings(fbxIOSetting);
	if (fbxImporter->Initialize(filePath,-1,fbxManager->GetIOSettings()))
	{
		FbxScene*scene = FbxScene::Create(fbxManager, "");
		fbxImporter->Import(scene);

		FbxNode*rootNode = scene->GetRootNode();
		ImportNode(rootNode);
		scene->Destroy();
	}
	fbxImporter->Destroy();
	fbxIOSetting->Destroy();
	fbxManager->Destroy();
}

void FBXModel::Draw()
{

}